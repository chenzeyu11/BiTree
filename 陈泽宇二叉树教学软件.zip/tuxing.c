#include<stdio.h>
#include<graphics.h> 
typedef struct{
	char *text;
	char key;
	void (*func)();
}ItemType;
typedef struct Tree{
      char data;
      struct Tree *pLchild;
	  struct Tree *pRchild;	  
	  struct Tree *next;
	  unsigned char  ltag;
	  unsigned char  rtag;    /* 0指向孩子，1代表线索标志符。 */
	  double x;
	  double y;
}Tree;
typedef struct
{
  Tree data[100];   /* 用数组存储循环队列中的元素。 */
  int front;           /*     // 队列的头指针。 */
  int rear;             /*     // 队列的尾指针，指向队尾的下一个元素 */
}Queue;
char text1[30]="preorder";
char text2[30]="inorder";
char text3[30]="postorder";
char text4[30]="levorder";
char text5[30]="prethread";
char text6[30]="inthread";
char text7[30]="postthread";
char text8[30]="findnode";
char text9[30]="deletenode";
char text10[30]="insertnode";
char text11[30]="leaf";
char text12[30]="height";
char text13[30]="btree";
char text14[30]="assign";
char text15[30]="degree";
char text16[30]="exit";
char text17[30]="help";
void f1();
void f2();
void f3();
void f4();
void f5();
void f6();
void f7();
void f8();
void f9();
void f10();
void f11();
void f12();
void f13();
void f14();
void f15();
void f16();
void f17();
ItemType item[17]={text1,'1',f1,
				   text2,'2',f2,
				   text3,'3',f3,
				   text4,'4',f4,
				   text5,'5',f5,
				   text6,'6',f6,
				   text7,'7',f7,
				   text8,'8',f8,
				   text9,'9',f9,
				   text10,'10',f10,
				   text11,'11',f11,
				   text12,'12',f12,
				   text13,'13',f13,
				   text14,'14',f14,
				   text15,'15',f15,
				   text16,'16',f16,
				   text17,'17',f17};
void menu(ItemType *item,int n,Tree *PT);/*菜单*/
Tree *CreateTree(void);   /*  // 构建二叉树 // */
Tree  *Treelianjie(int *nP,char chh[],int max); /*连接二叉树节点*/
void jiediansheji(Tree *PT,double x,double y,double base); /*节点设计*/
void drawLeft(Tree *PT);/*左边连线*/
void drawRight(Tree *PT);/*右边连线*/
void huaxians(Tree *PT);/*删除树的结点画线用的*/
void Treechushi(Tree *PT); /* //  先序初始化  // */
void yuan(Tree *PT,double base); /*圆的位置设置*/
void yuans(Tree *PT,double base); /*圆的位置设置*/
void PreTreejiedian(Tree *PT,char chh[],int *n);/*先序节点设计*/
void InTreejiedian(Tree *PT,char chh[],int *n); /*中序节点设计*/
void PostTreejiedian(Tree *PT,char chh[],int *n); /*后序节点设计*/
Tree *chazhao(Tree *PT,char chh[],int *n);/*先序中序后序查找节点*/
void Treexu(Tree *PT,char chh[],int *n); /* //  先序中序后序  //*/ 

void PreThread(Tree *PT,char chh[],int *n,Tree *pre); /*线索二叉树先序 */
void InThread(Tree *PT,Tree *pre); /*线索二叉树中序 */
void PostThread(Tree *PT,Tree *pre);/*线索化二叉树后续*/
/*void Thread(Tree *PT,Tree *pre);*/
/*Tree *chazhao(Tree *PT,char chh[],int *n);/*先序中序后序查找节点*/
void TreeThread(Tree *PT,char chh[],int *n);  /*线索化二叉树执行*/

void LevelTree(Tree *PT,char bhh[],int *n); /*  //  层次遍历 // */
void CreateQueue(Queue *Q);/* //  构建队列  //  */
int EmptyQueue(Queue *Q); /* //  判断队列是否为空 // */
int FullQueue(Queue *Q);  /*  判断队列是否为满 */
int InQueue(Queue *Q,Tree *data); /*入队列 */
int DeQueue(Queue *Q,Tree *PT);    /* 出队列 */

Tree *chazhaoTree(Tree *PT,char input);  /*查找树的结点*/
int DeleteTree(Tree *PT,char data,Tree *pre); /*删除树的结点*/


int InSertTree(Tree *PT);/*插入树的结点初始化*/
int InSertTreeNode(Tree *PT,Tree *NewNode,char charu,int base,char insert); /*插入树的结点具体操作*/
void inserts(Tree *PT,Tree *NewNode,int base,char insert);/*插入树的结点排序*/
int panduan(Tree *PT,char data);/*判断插入树的结点是否重复*/
void InDel(Tree *PT,char charu,char insert); /*树的高度大于5就开始删除插入的结点*/
void Injiediansheji(Tree *PT,double x,double y,double base);/*重置结点*/
int	chazhaoyezijiedian(Tree *PT);/*查找叶子结点*/

int qiushugao(Tree *PT);/*求树高*/
void degree(Tree *PT,int shugao); /*求度*/
void degreeone(Tree *PT);/*求度*/
void degreetwo(Tree *PT);/*求度*/
void help(Tree *PT); /*帮助*/
void nextpage(Tree *PT);/*下一页*/
void escc();/*退出*/
main()
{
	    int gdriver, gmode, i,size;
	    int *buf;
	    struct fillsettingstype save; /*定义一个用来存储填充信息的结构变量*/
		Tree *PT;
	    
		PT=CreateTree();	
		
	    gdriver=DETECT;
        registerbgidriver(EGAVGA_driver); 
        initgraph(&gdriver, &gmode, "c:\\tc");
	    cleardevice(); 	  /*清空屏幕*/
		   
	    setviewport(0, 0, 639, 479, 1); /*定义一个图形窗口*/ 
        /*   setfillstyle(1, 2);      /*绿色以实填充*/ 
		setcolor(WHITE);   
		   rectangle(120, 140, 520, 340); 
           /*floodfill(50, 50, 14);*/ 
		   
        setcolor(15);
        settextstyle(1, 0, 0);   /*三重笔划字体, 水平放大8倍*/ 
        outtextxy(230, 150, "Binary Tree Demo v1.2"); 
        setusercharsize(2, 1, 4, 1);/*水平放大2倍, 垂直放大4倍*/
		   
	    setcolor(15);
        settextstyle(1, 0, 0);   /*三重笔划字体, 水平放大8倍*/ 
        outtextxy(270, 290, "loading..."); 
	    setusercharsize(2, 1, 4, 1);/*水平放大2倍, 垂直放大4倍*/
		   
	    setcolor(15);
        settextstyle(1, 0, 0);   /*三重笔划字体, 水平放大8倍*/ 
        outtextxy(130, 330, "Binary Tree Demo v1.2 Design by YANGCHEN in 2017 "); 
	    setusercharsize(2, 1, 4, 1);/*水平放大2倍, 垂直放大4倍*/
	   		   
	    setbkcolor(0);        /*设置图形背景*/ 
	/*	   line(100,200,330,200);  /*上面那条横线*/
	/*	   line(100,220,330,210);  /*下面那条横线*/	
	    rectangle(210, 270, 410, 280); 
		setcolor(WHITE);        /*作图色为白色*/ 
	    for(i=1;i<=40;i++)
		{
			bar(210,270,210+5*i,280);
			delay(1000);
		}
		cleardevice(); 	  /*清空屏幕*/
		jiediansheji(PT,300,-70,150); /*节点设计*/
	    drawLeft(PT);
	    drawRight(PT);
		while(1)
		{
			menu(item,17,PT);
		}
		closegraph();
		return 0;
}
void menu(ItemType *item,int n,Tree *PT)
{
	int a;
	int b;
	int i;
	char ch[30]={0};
	char dh[30]={0};
	char bh=0;
	char s[30]={0};
	a=b=i=0;
	
/*	setviewport(0,400,300,440,1);/*command所在窗口*/
/*	setcolor(15);
	settextstyle(2,0,5);
	settextjustify(0,2);
	outtextxy(0,0, " Your Command:");
	setviewport(0,420,639,479,1);*/
	setcolor(WHITE);        /*作图色为白色*/
	outtextxy(10,430, "Command:");
	bh=getch();
	while(bh!='\r')
	{
	/*	printf("%c  ",bh);*/
		if(bh==8)
		{	
			if(i<=0)
			{
				
			}
	/*		else if(i==1)
			{
				i--;
				for(b=0;b<=i;b++)
				{
					dh[b]=ch[b];
				}
				ch[i]='\0';
				setcolor(BLACK);        /*作图色为黑色*/ 
		/*		sprintf(s, "%s", dh); /*将数字转化为字符串*/ 
		/*		outtextxy(100,430,s);*/
		/*	}*/
			else
			{
				i--;
				for(b=0;b<=i;b++)
				{
					dh[b]=ch[b];
				}
				ch[i]='\0';
				setcolor(BLACK);        /*作图色为黑色*/ 
				sprintf(s,"%s", dh); /*将数字转化为字符串*/ 
				outtextxy(100,430,s);
				setcolor(WHITE);        /*作图色为白色*/ 
				sprintf(s, "%s", ch); /*将数字转化为字符串*/
				outtextxy(100, 430, s);
			}
		}
		else if(i==29)
		{
			setcolor(WHITE);        /*作图色为白色*/ 
			sprintf(s, "%s", ch); /*将数字转化为字符串*/
			outtextxy(100, 430, s);
		}
		else
		{
			ch[i]=bh;
			i++;
	/*		for(b=0;b<=i;b++)
			{
				dh[b]=ch[b];
			}
			setcolor(BLACK);        /*作图色为黑色*/ 
	/*		sprintf(s, "%s", dh); /*将数字转化为字符串*/ 
	/*		outtextxy(100,430,s);*/
			setcolor(WHITE);        /*作图色为白色*/ 
			sprintf(s, "%s", ch); /*将数字转化为字符串*/
			outtextxy(100, 430, s);
		}
		bh=getch();
	}	
/*	printf("%s\n",ch);*/
	while((strcmp(item[a].text,ch)!=0))
	{	
		a++;
	/*	printf("a==%d\n",a);*/
	/*	getch();*/
		if(a>=n)
		{
			Treechushi(PT); /* //  初始化  // */
			huaxians(PT);	/*返回查看二叉树*/
			setcolor(WHITE);        /*作图色为白色*/ 
			outtextxy(10, 450,"Input Error"); 
			setcolor(BLACK);        /*作图色为黑色*/ 
			sprintf(s, "%s", ch); /*将数字转化为字符串*/
			outtextxy(100, 430, s);
			return ;
		}
	}
	setcolor(BLACK);        /*作图色为黑色*/ 
	outtextxy(10, 450, "Input Error"); 
	item[a].func(PT);
/*	sprintf(s, "%s", ch); /*将数字转化为字符串*/
/*	outtextxy(100, 430, s);*/
}

void f1(Tree *PT)
{
    char chh[30]={0};
    int *n;
    int w;
	  
    w=0;
    n=&w;	     	
	
	w=0;
	PreTreejiedian(PT,chh,n);/*先序节点设计*/
	Treechushi(PT); /* //  初始化  // */
 	w=0;
   	Treexu(PT,chh,n);  /*先序*/
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
}
void f2(Tree *PT)
{
    char chh[30]={0};
    int *n;
    int w;
	  
    w=0;
    n=&w;	     
	
	w=0;
	InTreejiedian(PT,chh,n);/*中序节点设计*/
	Treechushi(PT); /* //  初始化  // */
	w=0;
	Treexu(PT,chh,n);		/* //  中序  //  */
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
}
void f3(Tree *PT)
{
    char chh[30]={0};
    int *n;
    int w;
	  
    w=0;
    n=&w;	     	
	
	w=0;
	PostTreejiedian(PT,chh,n);/*后序节点设计*/
	Treechushi(PT); /* //  初始化  // */
	w=0;
	Treexu(PT,chh,n);		/* //  后序  //  */
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
}
void f4(Tree *PT)
{
    char bhh[30]={0};
    int *n;
    int w;
	  
    w=0;
    n=&w;	   		
	
	w=0;
	LevelTree(PT,bhh,n);    /*层次遍历节点设计*/
	Treechushi(PT); /* //  初始化  // */
	w=0;
	Treexu(PT,bhh,n);		/* //  中序  //  */
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,bhh); 
}
void f5(Tree *PT)
{
    char chh[30]={0};
	Tree *pre;
    int *n;
    int w;
	  
    w=0;
    n=&w;	   
    pre=NULL;  	
	
	Treechushi(PT); /* //  初始化  */
	w=0;
	PreTreejiedian(PT,chh,n);/*先序节点设计*/
	w=0;
	PreThread(PT,chh,n,pre);	/*线索二叉树先序中序后序*/
	/*	Treechushi(PT); /* //  初始化  // */
	w=0;
	setcolor(WHITE);
	line(440,15,480,15);
	outtextxy(500, 10, "normal traverse"); 
	setcolor(RED);
	line(440,25,480,25);
	outtextxy(500, 20, "pre thread");
	setcolor(LIGHTBLUE);
	line(440,35,480,35);
	outtextxy(500, 30, "post thread");
	setcolor(BLUE);
	line(440,45,480,45);
	outtextxy(500, 40, "pre&post thread");
	TreeThread(PT,chh,n);  /*排列先序*/
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
	
}	
void f6(Tree *PT)
{
    char chh[30]={0};
	Tree *pre;
    int *n;
    int w;
	
	pre=NULL;
    w=0;
    n=&w;	    
	
	Treechushi(PT); /* //  初始化  */
	w=0;
	InTreejiedian(PT,chh,n);/*中序节点设计*/
	w=0;	
	PreThread(PT,chh,n,pre);	/*线索二叉树先序中序后序*/
	/*	Treechushi(PT); /* //  初始化  // */
	w=0;
	setcolor(WHITE);
	line(440,15,480,15);
	outtextxy(500, 10, "normal traverse"); 
	setcolor(RED);
	line(440,25,480,25);
	outtextxy(500, 20, "pre thread");
	setcolor(LIGHTBLUE);
	line(440,35,480,35);
	outtextxy(500, 30, "post thread");
	setcolor(BLUE);
	line(440,45,480,45);
	outtextxy(500, 40, "pre&post thread");
	TreeThread(PT,chh,n);  /*中序*/
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
}
void f7(Tree *PT)
{
    char chh[30]={0};
    Tree *pre;
    int *n;
    int w;
	  
    w=0;
    n=&w;	   
    pre=NULL;  
    	
	
	Treechushi(PT); /* //  初始化  */
	w=0;
	PostTreejiedian(PT,chh,n);/*后序节点设计*/
	w=0;	
	PreThread(PT,chh,n,pre);	/*线索二叉树先序中序后序*/
	/*	Treechushi(PT); /* //  初始化  // */
	w=0;		
	setcolor(WHITE);
	line(440,15,480,15);
	outtextxy(500, 10, "normal traverse"); 
	setcolor(RED);
	line(440,25,480,25);
	outtextxy(500, 20, "pre thread");
	setcolor(LIGHTBLUE);
	line(440,35,480,35);
	outtextxy(500, 30, "post thread");
	setcolor(BLUE);
	line(440,45,480,45);
	outtextxy(500, 40, "pre&post thread");
	TreeThread(PT,chh,n);  /*后序*/
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	yuans(PT,150);
	
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,chh); 
}
void f8(Tree *PT)
{
    char s[30];
	char chh[30];
	Tree *prt;
	char input;
	setcolor(WHITE);
	outtextxy(0,0,"input data:");
	input=getch();
/*	sprintf(s, "%c",input); /*将数字转化为字符串*/
/*	outtextxy(0,10,s);
/*	scanf("%c",&input);
	getchar();  /*查找树的结点*/
	prt=chazhaoTree(PT,input);
	Treechushi(PT); /* //  初始化  // */
	huaxians(PT);
	if(prt!=NULL)
	{
		setcolor(1);/*设置画图形的颜色*/
		/*setlinestyle(0,0,1);*/
		setfillstyle(1,4); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(prt->x+4,prt->y+5,9);
		/*	getch(); /*断点，方便观察现象*/
		floodfill(prt->x+4,prt->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",prt->data); /*将数字转化为字符串*/
		setcolor(1);
		outtextxy(prt->x,prt->y,s);      /*指定位置输出字符串*/
	
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		sprintf(s, "findnode Success is %c",input); /*将数字转化为字符串*/
		outtextxy(100, 450,s);
	
	}
	else
	{
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		outtextxy(100, 450,"findnode Error");
	}
}
void f9(Tree *PT)
{
    Tree *pre;
	Tree *prt;
	char s[30];
    char input;	   
    pre=NULL;  	
	setcolor(WHITE);
	outtextxy(0,0,"DeleteNode data:");
/*	setcolor(BLACK);
	sprintf(s, "%c",input); /*将数字转化为字符串*/
/*	outtextxy(0,10,s);*/
	input=getch();
	prt=chazhaoTree(PT,input);
	if(prt!=NULL)
	{
		DeleteTree(PT,input,pre);
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);
	
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		sprintf(s,"DeleteNode is %c",input); /*将数字转化为字符串*/
		outtextxy(100, 450,s);
	}
	else
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		outtextxy(100, 450,"InsertNode error");
	}
}
void f10(Tree *PT)
{
	int i;	  
	i=InSertTree(PT);  /*插入树的结点*/
/*	printf("i===%d",i);
	getch();*/
	if(i==1)
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		outtextxy(100, 450,"InsertNode error");
	}	
	else
	{
/*		printf("i===2");*/
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);
		setcolor(LIGHTRED);    /*作图色为淡红色*/ 
		outtextxy(100, 450,"InsertNode Success");
	}
}
void f11(Tree *PT)
{
	Treechushi(PT); /* //  初始化  // */
	huaxians(PT);
	chazhaoyezijiedian(PT);/*查找叶子结点*/
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	outtextxy(100, 450,"Find Success");
}
void f12(Tree *PT)
{
	char s[30];
    int shugao;
	Treechushi(PT); /* //  初始化  // */
	huaxians(PT);   
	shugao=qiushugao(PT);   /*求树高*/
	setcolor(LIGHTRED);    /*作图色为淡红色*/ 
	sprintf(s, "height is %d", shugao); /*将数字转化为字符串*/ 
	outtextxy(100, 450, s);
}
void f13(Tree *PT)
{	  
	Treechushi(PT); /* //  初始化  // */
	huaxians(PT);	/*返回查看二叉树*/
}
void f14(Tree *PT)
{
    Tree *prt;
	Tree *pre;
    char input;	
    char s[30];
	char d[30];
	char f[30];
	setcolor(WHITE);
	outtextxy(0,0,"Input your change Node's data:");
	input=getch();
	setcolor(WHITE);
	sprintf(s,"%c",input); /*将数字转化为字符串*/
	sprintf(d,"%c",input); /*将数字转化为字符串*/
	outtextxy(0,10,s);
	prt=chazhaoTree(PT,input);
	if(prt!=NULL)
	{
		setcolor(WHITE);
		outtextxy(0,20,"Input Node's data:");
		input=getch();
		pre=chazhaoTree(PT,input);
		if(pre==NULL)
		{
			setcolor(WHITE);
			sprintf(s,"%c",input); /*将数字转化为字符串*/
			sprintf(f,"  repeated is %c",input); /*将数字转化为字符串*/
			outtextxy(0,30,s);
			prt->data=input;
			Treechushi(PT); /* //  初始化  // */
			huaxians(PT);	/*返回查看二叉树*/
			
			setcolor(LIGHTRED);    /*作图色为淡红色*/
			outtextxy(100, 450,d);
			outtextxy(100, 450,f);
		}
		else
		{
			Treechushi(PT); /* //  初始化  // */
			huaxians(PT);	/*返回查看二叉树*/
			setcolor(WHITE);
			outtextxy(100, 450,"Input Error");
		}
	}
	else
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		setcolor(WHITE);
		outtextxy(100, 450,"Input Error");
	}
	
}
void f15(Tree *PT)
{
    char shugao;
/*	char a;*/
	char s[30];
	setcolor(WHITE); 
	outtextxy(0,0,"degree:");
	shugao=getch();
	setcolor(WHITE);
	sprintf(s,"%c",shugao); /*将数字转化为字符串*/
	outtextxy(0,10,s); 
	shugao=shugao-48;
/*	shugao=shugao-'0';*/
	degree(PT,shugao);	
	if(shugao<3&&shugao>=0)
	{
		setcolor(LIGHTRED);    /*作图色为淡红色*/	
		shugao=shugao+48;
		sprintf(s,"Degree Success is %c",shugao); /*将数字转化为字符串*/
		outtextxy(100, 450,s);
	}
	else
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		setcolor(WHITE);
		outtextxy(100, 450,"Input Error");
	}
}
void f16()
{
		closegraph();
		exit(0);
}
void f17(Tree *PT)
{
	help(PT);
}
Tree *CreateTree(void)   /*  // 构建二叉树 // */
{
	Tree *pT[100];
	FILE *fp;
	char ch;
	int *i;
	char chh[100]={0};
	int n=0;
	int w=0;
	i=&w;
/*	pT[]=(Tree *)malloc(sizeof(Tree));*/
	if((fp=fopen("demo.txt","r"))==NULL)
	{
		printf("Failure to open demo.txt!\n");
		exit(0);
	}
	while((ch=fgetc(fp))!=EOF)
	{
		chh[n]=ch;
		n=n+1;
	}
	fclose(fp);
	return Treelianjie(i,chh,n);
	
}	
Tree  *Treelianjie(int *nP,char chh[],int max) /*连接二叉树节点*/
{
	Tree *TreeP;
	if(*nP>=max)
	{
		return NULL;
	}
    if(chh[*nP]=='.')
	{	
	 return NULL;
	}
	else
	{	
		TreeP=(Tree *)malloc(sizeof(Tree));
		TreeP->data=chh[*nP];
		*nP=*nP+1;
		TreeP->pLchild=Treelianjie(nP,chh,max);
		*nP=*nP+1;
		TreeP->pRchild=Treelianjie(nP,chh,max);
		return TreeP;
	}
	/*	PT->pLchild=Treelianjie(PT+1);
		PT->pRchild=Treelianjie(PT+1);*/
	
}
void jiediansheji(Tree *PT,double x,double y,double base) /*节点设计*/
{
	char s[100];
	y=y+80;
    if(PT->data==NULL)
	{
	 return ;
	}
	else
	{	
		setcolor(15);/*设置画图形的颜色*/
		/*setlinestyle(0,0,1);*/
		setfillstyle(1,2); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(x+4,y+5,10);
	/*	getch(); /*断点，方便观察现象*/
		floodfill(x+4, y+5,15); /*进行填充，绿色边框内的内容填充*/
		PT->x=x;
		PT->y=y;
		PT->ltag=0;
		PT->rtag=0;
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(15);
        outtextxy(x, y, s);      /*指定位置输出字符串*/
	
		jiediansheji(PT->pLchild,x-base,y,base/2);
		jiediansheji(PT->pRchild,x+base,y,base/2);
	}
}
void drawLeft(Tree *PT)
{
	if(PT==NULL)
	{
		return ;
	}
	if(PT->pLchild==NULL)
	{
		return ;
	}
		setcolor(WHITE);
     	line(PT->x-8,PT->y+8,PT->pLchild->x+5,PT->pLchild->y-8);
		drawLeft(PT->pLchild);
		drawLeft(PT->pRchild);
} 
void drawRight(Tree *PT)
{
	if(PT==NULL)
	{
		return ;
	}
	if(PT->pRchild==NULL)
	{
		return ;
	}
		setcolor(WHITE);
		line(PT->x+14,PT->y+8,PT->pRchild->x+5,PT->pRchild->y-8);
		drawRight(PT->pLchild);
		drawRight(PT->pRchild);
}
void huaxians(Tree *PT) /*删除树的结点画线用的*/
{
		if(PT==NULL)
		{
			return ;
		}
		if(PT->pLchild!=NULL)
		{
			if(PT->ltag==0)
			{
				setcolor(WHITE);
				line(PT->x-8,PT->y+8,PT->pLchild->x+5,PT->pLchild->y-8);
			}
		}
		if(PT->pRchild!=NULL)
		{
			if(PT->rtag==0)
			{
				setcolor(WHITE);
				line(PT->x+14,PT->y+8,PT->pRchild->x+5,PT->pRchild->y-8);
			}
		}
		if(PT->ltag==0)
		{
			huaxians(PT->pLchild);
		}
		if(PT->rtag==0)
		{
			huaxians(PT->pRchild);
		}
}
void Treechushi(Tree *PT) /* //  初始化  // */
{
	cleardevice();
	yuan(PT,150);
/*	if(PT==NULL)
	{
		return ;
	}
	setcolor(BLUE);
    line(PT->x-8,PT->y+8,PT->pLchild->x+5,PT->pLchild->y-8);
	delay(1000);
	PreTree(PT->pLchild);
	PreTree(PT->pRchild);*/
}
void yuan(Tree *PT,double base) /*圆的位置设置*/
{
	char s[100];
    if(PT->data==NULL)
	{
	 return ;
	}
	else
	{	
		setcolor(15);/*设置画图形的颜色*/
		/*setlinestyle(0,0,1);*/
		setfillstyle(1,2); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,10);
	/*	getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,15); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(15);
        outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
	/*	getch();*/
		if(PT->ltag==0)
		{
			yuan(PT->pLchild,base/2);
		}
		if(PT->rtag==0)
		{
			yuan(PT->pRchild,base/2);
		}
		
	}
}	
void yuans(Tree *PT,double base) /*圆的位置设置*/
{
	char s[100];
    if(PT->data==NULL)
	{
	 return ;
	}
	else
	{	
		setcolor(1);/*设置画图形的颜色*/
		/*setlinestyle(0,0,1);*/
		setfillstyle(1,1); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,10);
	/*	getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(15);
        outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
	/*	getch(); /*断点，方便观察现象*/
		if(PT->ltag==0)
		{
			yuans(PT->pLchild,base/2);
		}
		if(PT->rtag==0)
		{
			yuans(PT->pRchild,base/2);
		}
		
	}
}	
void Treexu(Tree *PT,char chh[],int *n) /* //  先序中序后序  //*/ 
{
	Tree *PY;
	Tree *PC;
	if(chh[*n]==NULL)
	{	
		return ;
	}
	if(PT==NULL)
	{
		return ;
	}
	PY=chazhao(PT,chh,n);
	*n=*n+1;
	PC=chazhao(PT,chh,n);
	if(PC==NULL)
	{
		return ;
	}
	setcolor(WHITE);
    line(PY->x+3,PY->y+4,PC->x+3,PC->y+4);
	delay(1000);
	Treexu(PT,chh,n);
}
Tree *chazhao(Tree *PT,char chh[],int *n)   /* //  先序中序后序查找节点  //*/ 
{
	Tree *Node=NULL;
/*	printf("%d %c ",*n,chh[*n]);*/
	if(PT==NULL)
	{
		
		return NULL;
	} 
	if(PT->data==chh[*n])
	{
	/*	printf("%d %c ",*n,chh[*n]);*/
		return PT;
	}
	if(PT->ltag==0)
	{		
		Node=chazhao(PT->pLchild,chh,n);
	}	
	if(Node==NULL)
	{
		if(PT->rtag==0)
		{
			Node=chazhao(PT->pRchild,chh,n);
		}
	}
/*	printf("%d %c ",*n,chh[*n]);*/
	return Node;
}
void PreTreejiedian(Tree *PT,char chh[],int *n) /*先序节点设计*/
{
	if(PT==NULL)
	{
		return ;
	}
	chh[*n]=PT->data;   
/*	printf("1111%d %c",*n,chh[*n]);
	getch();*/
	*n=*n+1;
	if(PT->ltag==0)
	{
		PreTreejiedian(PT->pLchild,chh,n);
	}
	if(PT->rtag==0)
	{
		PreTreejiedian(PT->pRchild,chh,n);
	}
}
void InTreejiedian(Tree *PT,char chh[],int *n) /*中序节点设计*/
{
	if(PT==NULL)
	{
		return ;
	}
	if(PT->ltag==0)
	{
		InTreejiedian(PT->pLchild,chh,n);
	}
		chh[*n]=PT->data;
		*n=*n+1;
	if(PT->rtag==0)
	{
		InTreejiedian(PT->pRchild,chh,n);
	}
}
void PostTreejiedian(Tree *PT,char chh[],int *n) /*后序节点设计*/
{
	if(PT==NULL)
	{
		return ;
	}
	if(PT->ltag==0)
	{
		PostTreejiedian(PT->pLchild,chh,n);
	}
	if(PT->rtag==0)
	{
		PostTreejiedian(PT->pRchild,chh,n);
	}
	chh[*n]=PT->data;
/*	printf("%d %c ",*n,chh[*n]);
	getch();*/
	*n=*n+1;
}
void PreThread(Tree *PT,char chh[],int *n,Tree *pre) /*线索二叉树先序中序后序 */
{
	Tree *PY;
	if(chh[*n]!=NULL)
	{
	/* printf("mimi\n"); */
		PY=chazhao(PT,chh,n);
	/*	printf("%d %c ",*n,chh[*n]);
		getch();*/
	}
	else
	{	
		return ;
	}
	if(PY->pLchild==NULL)
	{
		PY->pLchild=pre;    /*pre代表上一个节点*/
		PY->ltag=1; 
	/* printf("LLLLPY->data===%c,pre===%c\n",PY->data,pre->data);*/
	}
    if((pre!=NULL)&&((pre)->pRchild==NULL))
    {
		pre->pRchild=PY; 
		pre->rtag=1;
    } 
	 pre=PY; /*pre===h;*/
	 *n=*n+1;/* *n=*n+1 ===p这个节点*/
     PreThread(PT,chh,n,pre);  /* 递归线索化左子树。*/ 
}
void TreeThread(Tree *PT,char chh[],int *n)  /*线索化二叉树执行*/
{
	Tree *PY;
	Tree *PC;
	if(chh[*n]==NULL)
	{	
		return ;
	}
	if(chh[*n+1]==NULL)
	{
		return ;
	}
	if(PT==NULL)
	{
		return ;
	}
	PY=chazhao(PT,chh,n);
/*	printf("chh[%d]=%c\n",*n,PY->data);*/
	
	*n=*n+1;
	PC=chazhao(PT,chh,n);
/*	getch();*/
/*	if(PC==NULL)
	{
		return ;
	} */
	if(PY->ltag==1&&PY->rtag==0)
	{
		if(PC->ltag==0&&PC->rtag==0)
		{
			setcolor(WHITE);
			line(PY->x,PY->y,PC->x,PC->y);
		}
		else if(PC!=NULL)
		{
			setcolor(RED);
			line(PY->x,PY->y,PC->x,PC->y);
		}
	/*	setcolor(WHITE);
		line(PY->x,PY->y,PC->x,PC->y);
		delay(1000);
		getch();*/
	   /* TreeThread(PT,chh,n,tag);*/
	}
	else if(PY->ltag==1&&PY->rtag==1)
	{	
		if(PC->ltag==1)
		{
			setcolor(BLUE);
			line(PY->x,PY->y,PC->x,PC->y);
		/*	TreeThread(PT,chh,n,tag);*/
			
		}
		if(PC->ltag==0)
		{
			setcolor(LIGHTBLUE);
			line(PY->x,PY->y,PC->x,PC->y);
		}
	/*TreeThread(PT,chh,n,tag);*/
	}
	else if(PY->ltag==0&&PY->rtag==1)
	{
			setcolor(LIGHTBLUE);
			line(PY->x,PY->y,PC->x,PC->y);
	}
	else
	{
		if(PC->ltag==1&&PC!=NULL)
		{
			setcolor(RED);
			line(PY->x,PY->y,PC->x,PC->y);
		}
		if(PC->ltag==0&&PC!=NULL)
		{
		setcolor(WHITE);
		line(PY->x,PY->y,PC->x,PC->y);
		/*TreeThread(PT,chh,n,tag);*/
		}
	}	
	delay(1000);
	TreeThread(PT,chh,n);
}
void LevelTree(Tree *PT,char bhh[],int *n)/* //  层次遍历节点设计 //*/ 
{
	Tree *PC=(Tree *)malloc(sizeof(Tree));
	Queue *Q=(Queue *)malloc(sizeof(Queue));
	CreateQueue(Q);
	if(PT!=NULL)
	{
		InQueue(Q,PT);
	}
	while (!EmptyQueue(Q)) {   /*   // 队不为空循环*/ 
        DeQueue(Q,PC);        /*   // 出队时的节点 */
		bhh[*n]=PC->data;
	/*	printf("%d  pT---->data===%c\t",*n,bhh[*n]);
		getch();*/
		*n=*n+1;		
        if (PC->pLchild != NULL&&PC->ltag==0) { /*// 有左孩子时将该节点进队列*/ 
            InQueue(Q,PC->pLchild);
        }
        if (PC->pRchild != NULL&&PC->rtag==0) { /*// 有右孩子时将该节点进队列 */
            InQueue(Q,PC->pRchild);
        }
    }
	free(Q);
	free(PC);
}	
void CreateQueue(Queue *Q)/* //  构建队列  // */
{
	Q->front=0;
	Q->rear=0;
}
int InQueue(Queue *Q,Tree *PT) /* 入队列 */ 
{	
	if(!Q||!PT)
	{
		return 0;
	}
	
	if(FullQueue(Q))
	{
		printf("队列已满\n");
		return 0;
	}	
		Q->rear=(Q->rear+1)%100;
		Q->data[Q->rear]=*PT;
	
	return 1;	
}	
int EmptyQueue(Queue *Q)/* //  判断队列是否为空*/ 
{
	if(Q->front==Q->rear)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
	
	
int FullQueue(Queue *Q)   /* 判断队列是否为满 */
{
	if (((Q->rear+1)%100) == Q->front) return 1;
}
int DeQueue(Queue *Q,Tree *PT)
{
    /* 判断是否空了。空（取出失败）-返回假，不空（取出成功）-返回真*/ 
    if (Q->front == Q->rear)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	{
        return 0;
    }
    Q->front=(Q->front+1)%100;;               /* // 尾指针加 1*/ 
    *PT=Q->data[Q->front]; /*// 取值*/ 
    return 1;
}
Tree * chazhaoTree(Tree *PT,char input)/*查找树的结点*/
{
	Tree *Node=NULL;
	if(PT==NULL)
	{
		return 0;
	}
	if(PT->data==input)
	{
		return PT;
	}
	if(PT->ltag==0)
	{
		Node=chazhaoTree(PT->pLchild,input);
	}
	if(Node==NULL)
	{
		if(PT->rtag==0)
		{
			Node=chazhaoTree(PT->pRchild,input);
		}
	}
	return Node;
}
int DeleteTree(Tree *PT,char data,Tree *pre) /*删除树的结点*/
{	
	Tree *DeleteNode;
	Tree *biaoji;
	if(PT==NULL)
	{
		return 0;
	}
	if(PT->data!=data)
	{
		pre=PT;
		if(PT->ltag==0)
		{
			DeleteTree(PT->pLchild,data,pre);
		}
		if(PT->rtag==0)
		{
			DeleteTree(PT->pRchild,data,pre);
		}
	}
	else
	{
	
			if(pre->pLchild==PT)
			{
				pre->pLchild=NULL;
				free(PT);
			}
			if(pre->pRchild==PT)
			{
				pre->pRchild=NULL;
				free(PT);
			}
			return 1;
	}	 
  /*                 A   			    */
  /*			 /        \				*/
  /*			B          C			*/
  /*		  /   \       /  \ 			*/
  /*		 E	   D     F    G			*/
  /*		/ \   / \   / \  / \		*/  /*  P  H  Q  E  R  I  S  B  J  D  K  A  F  M  T  C  G  N */ /*中序遍历*/
  /*	   H   I J	 K	   M	N		*/	
  /*      / \ / \		  	\		    */	
  /*     p	Q R	 S		     T			*/
}		
int InSertTree(Tree *PT)/*插入树的结点*/
{					
	Tree *NewNode;
/*	Tree *pre=NULL;*/
	char data;
	char charu;
	int shugao;
	char insert;
	int i;
	char s[30];
	NewNode=(Tree *)malloc(sizeof(Tree));
	setcolor(WHITE);
	outtextxy(0,0,"Plese NewNode->data");
	data=getch();
	setcolor(WHITE);    /*作图色为淡红色*/ 
	sprintf(s,"%c",data);
	outtextxy(0, 10,s);
	i=panduan(PT,data);
	if(i==1)
	{
		return 1;
	}
	setcolor(WHITE);
	outtextxy(0,20,"InsertNode is:");
	charu=getch();
	setcolor(WHITE);    /*作图色为淡红色*/ 
	sprintf(s,"%c",charu);
	outtextxy(0, 30,s);
	NewNode->data=data;
	NewNode->ltag=0;
	NewNode->rtag=0;
	outtextxy(0,40,"Your Node is (L or R)?");
	insert=getch();
	sprintf(s,"%c",insert);
	outtextxy(0,50,s);
	Injiediansheji(PT,300,-70,150); /*节点设计*/
	i=InSertTreeNode(PT,NewNode,charu,150,insert);
/*	inserts(PT,NewNode,150);*/
	if(i==1)
	{
		return 1;
	}
	shugao=qiushugao(PT);   
/*	printf("shugao==%d\n",shugao);
	getch();*/
	if(shugao>5)
	{
		InDel(PT,charu,insert);
		Injiediansheji(PT,300,-70,150); /*节点设计*/
		return 1;
	}
}			
int InSertTreeNode(Tree *PT,Tree *NewNode,char charu,int base,char insert)/*插入树的结点具体操作*/
{
/*	char insert;*/
	char s[30];
/*	int shugao;*/
	int i;
	Tree *pre=NULL;
	char charuu=charu;
	
	if(PT->data==NULL)
	{
		return 0;
	}
	if(PT->data!=charu)
	{
		if(PT->ltag==0)
		{
			i=InSertTreeNode(PT->pLchild,NewNode,charuu,base/2,insert);
			if(i==1)
			{
				return i;
			}
		}
		if(PT->rtag==0)
		{
			i=InSertTreeNode(PT->pRchild,NewNode,charuu,base/2,insert);
			if(i==1)
			{
				return i;
			}
		}
	}
  /*                 A   			    */
  /*			 /        \				*/
  /*			B          C			*/
  /*		  /   \       /  \ 			*/
  /*		 E	   D     F    G			*/
  /*		/ \   / \   / \  / \		*/  /*  P  H  Q  E  R  I  S  B  J  D  K  A  F  M  T  C  G  N */ /*中序遍历*/
  /*	   H   I J	 K	   M	N		*/	
  /*      / \ / \		  	\		    */	
  /*     p	Q R	 S		     T			*/
	else
	{
		
		if(insert=='L'||insert=='l')
		{
			pre=PT;
			PT=PT->pLchild;
	/*		if(PT==NULL)
			{
				NewNode->pLchild=NULL;
				NewNode->pRchild=NULL;
			}*/
			NewNode->pLchild=PT;
			NewNode->pRchild=NULL;
			pre->pLchild=NewNode;
			NewNode->x=pre->x-base;
			NewNode->y=pre->y+80;
			inserts(PT,NewNode,base/2,insert);
		/*	printf("base==%d",base);
			getch();*/
			
		}
		else if(insert=='R'||insert=='r')
		{
			pre=PT;
			PT=PT->pRchild;
			NewNode->pRchild=PT;
			pre->pRchild=NewNode;
			NewNode->x=pre->x+base;
			NewNode->y=pre->y+80;
			NewNode->pLchild=NULL;
			inserts(PT,NewNode,base/2,insert);
		/*	printf("base==%d",base);
			getch();*/
		/*	inserts(PT,NewNode,150);*/
		}
		else
		{
			return 1;
		}
		return 0;
	}
		
  /*                 A   			    */
  /*			 /        \				*/
  /*			B          C			*/
  /*		  /   \       /  \ 			*/
  /*		 E	   D     F    G			*/
  /*		/ \   / \   / \  / \		*/  /*  P  H  Q  E  R  I  S  B  J  D  K  A  F  M  T  C  G  N */ /*中序遍历*/
  /*	   H   I J	 K	   M	N		*/	
  /*      / \ / \		  	\		    */	
  /*     p	Q R	 S		     T			*/	
}
void inserts(Tree *PT,Tree *NewNode,int base,char insert)/*插入树的结点排序*/
{
	char left='l';
	char right='r';
	char s[30];
/*	int shugao;*/
	int i;
	Tree *pre=NULL;
	if(PT==NULL)
	{
		return ;
	}
	else
	{
		if(insert=='L'||insert=='l')
		{
			PT->x=NewNode->x-base;
			PT->y=NewNode->y+80;
			pre=PT;
		}
		if(insert=='R'||insert=='r')
		{
			PT->x=NewNode->x+base;
			PT->y=NewNode->y+80;
			pre=PT;
		}
		if(PT->pLchild->ltag==1&&(PT->pLchild->rtag==1))
		{
			PT->pLchild->ltag=0;
			PT->pLchild->rtag=0;
			PT->pLchild->pLchild=NULL;
			PT->pLchild->pRchild=NULL;	
		}
		if(PT->pRchild->ltag==1&&(PT->pRchild->rtag==1))
		{
			PT->pRchild->ltag=0;
			PT->pRchild->rtag=0;
			PT->pRchild->pLchild=NULL;
			PT->pRchild->pRchild=NULL;	
		}
		
		if(PT->pLchild->ltag==0)
		{
			inserts(PT->pLchild,pre,base/2,left);
		/*	printf("%c  base=%d  ",PT->data,base);
			getch();*/
		}
		if(PT->pRchild->rtag==0)
		{
			inserts(PT->pRchild,pre,base/2,right);
		/*	printf("%c  base=%d  ",PT->data,base);
			getch();*/
		}
	}
}
void  Injiediansheji(Tree *PT,double x,double y,double base)/*重置结点*/	
{
	y=y+80;		/*Injiediansheji(PT,300,-70,150); /*节点设计*/
    if(PT->data==NULL)
	{
	 return ;
	}
	else
	{	
		if(PT->ltag==0)
		{
			PT->x=x;
			PT->y=y;
		}
		if(PT->rtag==0)
		{
			PT->x=x;
			PT->y=y;
		}
		if(PT->ltag==1)
		{
			PT->ltag=0;
			PT->pLchild=NULL;
			PT->x=x;
			PT->y=y;
		}
		if(PT->rtag==1)
		{
			PT->rtag=0;
			PT->pRchild=NULL;
			PT->x=x;
			PT->y=y;
		}
		Injiediansheji(PT->pLchild,x-base,y,base/2);
		Injiediansheji(PT->pRchild,x+base,y,base/2);
	
	}
}
void InDel(Tree *PT,char charu,char insert) /*树的高度大于5就开始删除插入的结点*/
{
	Tree *pre;
	Tree *prt;
	if(PT->data==NULL)
	{
		return ;
	}
	if(PT->data!=charu)
	{
		if(PT->ltag==0)
		{
			InDel(PT->pLchild,charu,insert);
		}
		if(PT->rtag==0)
		{
			InDel(PT->pRchild,charu,insert);
		}
	}
	else
	{
		if(insert=='L'||insert=='l')
		{
			pre=PT;
			PT=PT->pLchild;
			prt=PT;
			PT=PT->pLchild;
			pre->pLchild=PT;
			
			prt->pLchild=NULL;
			prt->pRchild=NULL;
			prt->data=NULL;
			prt->ltag=0;
			prt->rtag=0;
			free(prt);
		}
		if(insert=='R'||insert=='r')
		{
			pre=PT;
			PT=PT->pRchild;
			prt=PT;
			PT=PT->pRchild;
			pre->pRchild=PT;
			
			prt->pLchild=NULL;
			prt->pRchild=NULL;
			prt->data=NULL;
			prt->ltag=0;
			prt->rtag=0;
			free(prt);
		}
	}
}
int panduan(Tree *PT,char data)
{
	int a;

	if(PT==NULL)
	{
		return 0;
	}
	if(PT->data==data)
	{
		return 1;
	}
	if(PT->ltag==0)
	{
		a=panduan(PT->pLchild,data);
		if(a==1)
		{
			return a;
		}
	}
	if(PT->rtag==0)
	{
		a=panduan(PT->pRchild,data);
		if(a==1)
		{
			return a;
		}	
	}
/*	if(a==1)
	{
		return 1;
	}*/
		return 0;
}
int chazhaoyezijiedian(Tree *PT)/*查找叶子结点*/
{
	char s[100];
	if(PT==NULL)   /*空结点返回*/
	{
		return 0;
	}
	if((PT->pLchild==NULL&&(PT->pRchild==NULL))||(PT->ltag==1&&PT->rtag==1))
	{
		setcolor(1);
	/*	printf("%c ",PT->data);*/
		setfillstyle(1,4); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,9);
	/*	getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(1);
		outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
/*	printf("PT->ltag==%d&&PT->rtag==%d\n",PT->ltag,PT->rtag);*/
	}
	else
	{
		if(PT->ltag==0)
		{
			chazhaoyezijiedian(PT->pLchild);
		}
		if(PT->rtag==0)
		{
			chazhaoyezijiedian(PT->pRchild);
		}
	}
	return 1;
  /*                 A   			    */
  /*			 /        \				*/
  /*			B          C			*/
  /*		  /   \       /  \ 			*/
  /*		 E	   D     F    G			*/
  /*		/ \   / \   / \  / \		*/  /*  P  H  Q  E  R  I  S  B  J  D  K  A  F  M  T  C  G  N */ /*中序遍历*/
  /*	   H   I J	 K	   M	N		*/	
  /*      / \ / \		  	\		    */	
  /*     p	Q R	 S		     T			*/
}
int qiushugao(Tree *PT)  /*求树高*/
{
	int countleft;
	int countright;
/*	printf(" %c ",PT->data);
	getch();*/
	if(PT==NULL)
	{
		return 0;
	}
	if(PT->ltag==1&&PT->rtag==1)
	{
		return 1;
	}
	if(PT->ltag==0)
	{	
		countleft=qiushugao(PT->pLchild);
	/*	printf("%c countleft=%d  ",PT->data,countleft);
		getch();*/
	}
	else
	{
		countleft=0;
	}
	if(PT->rtag==0)
	{	
		countright=qiushugao(PT->pRchild);
	/*	printf("%c countright=%d\n",PT->data,countright);
		getch();*/
	}
	else
	{
		countright=0;
	}
	if(countleft>countright)
	{
		return countleft+1;
	}
	else
	{
		return countright+1;
	}
}
void degree(Tree *PT,int shugao)
{
	if(shugao==0)
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		chazhaoyezijiedian(PT);
	}
	else if(shugao==1)
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		degreeone(PT);
	}
	else if(shugao==2)
	{
		Treechushi(PT); /* //  初始化  // */
		huaxians(PT);	/*返回查看二叉树*/
		degreetwo(PT);
	}
	else
	{
		return ;
	}
}
void degreeone(Tree *PT)
{
	char s[30];
	if(PT==NULL)   /*空结点返回*/
	{
		return ;
	}
	if((PT->pLchild==NULL||PT->ltag==1)&&(PT->pRchild!=NULL&&PT->rtag==0))
	{
		setcolor(1);
/*		printf("%c ",PT->data);*/
		setfillstyle(1,4); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,9);
/*		getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(1);
		outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
/*		printf("111PT->data=%c,PT->ltag==%d&&PT->rtag==%d\n",PT->data,PT->ltag,PT->rtag);*/
	}
	else if((PT->pRchild==NULL||PT->rtag==1)&&(PT->pLchild!=NULL&&PT->ltag==0))
	{	
		setcolor(1);
/*		printf("%c ",PT->data);*/
		setfillstyle(1,4); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,9);
/*		getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(1);
		outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
/*		printf("2222PT->data=%c,PT->ltag==%d&&PT->rtag==%d\n",PT->data,PT->ltag,PT->rtag);*/
	}
	if(PT->ltag==0)
	{
		degreeone(PT->pLchild);
	}
	if(PT->rtag==0)
	{
		degreeone(PT->pRchild);
	}
}
void degreetwo(Tree *PT)
{
	char s[30];
	if(PT==NULL)   /*空结点返回*/
	{
		return ;
	}
	if((PT->pLchild!=NULL&&PT->pRchild!=NULL)&&(PT->ltag==0&&PT->rtag==0))
	{
		setcolor(1);
/*		printf("%c ",PT->data);*/
		setfillstyle(1,4); /*设置图形的填充方式，以及图形的填充颜色（4：红色）*/
		circle(PT->x+4,PT->y+5,9);
/*		getch(); /*断点，方便观察现象*/
		floodfill(PT->x+4,PT->y+5,1); /*进行填充，绿色边框内的内容填充*/
		sprintf(s, "%c",PT->data); /*将数字转化为字符串*/
		setcolor(1);
		outtextxy(PT->x,PT->y,s);      /*指定位置输出字符串*/
/*	printf("PT->ltag==%d&&PT->rtag==%d\n",PT->ltag,PT->rtag);*/
	}
	if(PT->ltag==0)
	{
		degreetwo(PT->pLchild);
	}
	if(PT->rtag==0)
	{
		degreetwo(PT->pRchild);
	}
}
void help(Tree *PT)
{
	char ch;
	cleardevice();
	setcolor(WHITE);
	outtextxy(180, 20,"Binary Tree Demo v1.2 HELP Document");
	outtextxy(50, 50,"Welcome to help document!  This software provides the basic operation of "); 
	outtextxy(0, 70,"binnary tree. You can input commands to control the operation of the binnary");
	outtextxy(0, 90,"tree and see the results at the graphical interface. The detailed command");
	outtextxy(0, 110,"information is on the next the page.Please press the N or P key to switch ");
	outtextxy(0, 130,"the page display, and press ESC to return the main view.However, you need to");
	outtextxy(0, 150,"provide a preorder sequence of extend binary trees in tree.txt");
	outtextxy(46,190,"* Software Instructions:");
	outtextxy(50,220,"Environment: Windows operating system / Dos");
	outtextxy(50,240,"Premise:     A preorder sequence of extend btree in tree.txt");
	outtextxy(50,260,"Command:     The next page");	
	outtextxy(46,440,"press [N] or [P]  turn to next/previous page.");
	outtextxy(46,460,"press [ESC] to exit help document");
	ch=getch();
	while(ch)
	{
		if(ch=='n'||ch=='N')
		{
			nextpage(PT);
		}
		if(ch=='p'||ch=='P')
		{
			help(PT);
		}
		if(ch==27)
		{
			escc(PT);
		}
		ch=getch();
	}
}
void nextpage(Tree *PT)
{
	char ch;
	cleardevice();
	setcolor(WHITE);
	outtextxy(180, 20,"Binary Tree Demo v1.2 HELP Document");
	outtextxy(5, 40,"Binary Tree Demo provide the following functions:");
	outtextxy(5, 60,"01. preorder");
	outtextxy(5, 80,"02. inorder");
	outtextxy(5, 100,"03.postorder");
	outtextxy(5, 120,"04.levorder");
	outtextxy(5, 140,"05.prethread");
	outtextxy(5, 160,"06.inthread");
	outtextxy(5, 180,"07.postthread");
	outtextxy(5, 200,"08.findnode");
	outtextxy(5, 220,"09.deletenode");
	outtextxy(5, 240,"10.insertnode");
	outtextxy(5, 260,"11.leaf");
	outtextxy(5, 280,"12.height");
	outtextxy(5, 300,"13.btree");
	outtextxy(5, 320,"14.assign");
	outtextxy(5, 340,"15.degree");
	outtextxy(5, 360,"16.exit");
	outtextxy(5, 380,"17.help");
	outtextxy(160, 450,"[press ESC to exit]");
	ch=getch();
    while(ch)
	{
		if(ch=='n'||ch=='N')
		{
			nextpage(PT);
		}
		if(ch=='p'||ch=='P')
		{
			help(PT);
		}
		if(ch==27)
		{
		    	escc(PT);
		}
		ch=getch();		
	}
}
void escc(Tree *PT)
{
	Treechushi(PT); /* //  初始化  // */
	huaxians(PT);	/*返回查看二叉树*/
	while(1)
	{
		menu(item,17,PT);
	}
}